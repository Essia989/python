from flask_app import app
from flask_app.models.user import User
from flask import render_template, redirect, request



@app.route('/')
@app.route('/', methods=['POST'])
def index():
    # redering the list of existing users 
    users = User.get_users()
    return render_template('users.html', users = users)

@app.route('/add_user')
def add_user():
    return render_template('add_user.html')



@app.route('/user/create',methods=['POST'])
def create_user():
    # adding a new user to DB
    User.create(request.form)
    dict = request.form
    for key in dict:
        print (f'key : ',key)
    #print(request.form)
    return redirect('/')