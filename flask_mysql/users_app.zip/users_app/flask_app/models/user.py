from flask_app.config.mysqlconnection import connectToMySQL, DB 

class User:
    def __init__(self,data):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def create(cls,data):
        #query to insert user into database
        #print (data['first_name']) 
        query ="INSERT INTO users (first_name,last_name,email,created_at, updated_at)  VALUES(%(first_name)s,%(last_name)s,%(email)s,now(),now())"
        return connectToMySQL(DB).query_db(query,data)

    @classmethod 
    def get_users(cls):
        #query to retrieve users from database
        query ="SELECT * FROM users;"

        results = connectToMySQL(DB).query_db(query)
        users = []
        for item in results:
            user = cls(item)
            users.append(user)
        return users