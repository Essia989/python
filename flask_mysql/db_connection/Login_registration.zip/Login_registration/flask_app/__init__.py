from flask import Flask

app = Flask(__name__)
app.secret_key = 'hn1y65h65dshji!%nxcb'